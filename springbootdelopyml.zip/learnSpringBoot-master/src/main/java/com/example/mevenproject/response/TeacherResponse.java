package com.example.mevenproject.response;

import lombok.Data;

@Data
public class TeacherResponse {
    private String name;
    private String email;
    private String password;
}
